/*
 * Q1: Stack using an array (no built-in stack library)
 * Operations: PUSH, POP, PEEK, DISPLAY
 * Handles: Stack Overflow and Stack Underflow
 */

#include <stdio.h>

#define MAX 5

int stack[MAX];
int top = -1;

void push(int x) {
    if (top == MAX - 1) {
        printf("Stack Overflow! Cannot push %d\n", x);
        return;
    }
    stack[++top] = x;
    printf("Pushed %d\n", x);
}

void pop() {
    if (top == -1) {
        printf("Stack Underflow! Nothing to pop\n");
        return;
    }
    printf("Popped %d\n", stack[top--]);
}

void peek() {
    if (top == -1) {
        printf("Stack is empty\n");
        return;
    }
    printf("Top element: %d\n", stack[top]);
}

void display() {
    if (top == -1) {
        printf("Stack is empty\n");
        return;
    }
    printf("Stack (top to bottom): ");
    for (int i = top; i >= 0; i--)
        printf("%d ", stack[i]);
    printf("\n");
}

int main() {
    int choice, x;

    while (1) {
        printf("\n--- STACK MENU ---\n");
        printf("1. PUSH\n2. POP\n3. PEEK\n4. DISPLAY\n5. EXIT\n");
        printf("Enter choice: ");
        if (scanf("%d", &choice) != 1) break;

        switch (choice) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &x);
                push(x);
                break;
            case 2: pop(); break;
            case 3: peek(); break;
            case 4: display(); break;
            case 5: return 0;
            default: printf("Invalid choice\n");
        }
    }
    return 0;
}
