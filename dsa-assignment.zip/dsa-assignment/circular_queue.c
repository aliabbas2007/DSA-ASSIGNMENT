/*
 * Q2: Circular Queue using an array
 * Operations: ENQUEUE, DEQUEUE, FRONT, DISPLAY
 * Full vs Empty is told apart using a 'count' variable.
 */

#include <stdio.h>

#define MAX 5

int queue[MAX];
int front = 0, rear = -1, count = 0;

int isFull()  { return count == MAX; }
int isEmpty() { return count == 0; }

void enqueue(int x) {
    if (isFull()) {
        printf("Queue is Full! Cannot enqueue %d\n", x);
        return;
    }
    rear = (rear + 1) % MAX;
    queue[rear] = x;
    count++;
    printf("Enqueued %d\n", x);
}

void dequeue() {
    if (isEmpty()) {
        printf("Queue is Empty! Nothing to dequeue\n");
        return;
    }
    printf("Dequeued %d\n", queue[front]);
    front = (front + 1) % MAX;
    count--;
}

void frontElement() {
    if (isEmpty()) {
        printf("Queue is Empty\n");
        return;
    }
    printf("Front element: %d\n", queue[front]);
}

void display() {
    if (isEmpty()) {
        printf("Queue is Empty\n");
        return;
    }
    printf("Queue (front to rear): ");
    for (int i = 0; i < count; i++)
        printf("%d ", queue[(front + i) % MAX]);
    printf("\n");
}

int main() {
    int choice, x;

    while (1) {
        printf("\n--- CIRCULAR QUEUE MENU ---\n");
        printf("1. ENQUEUE\n2. DEQUEUE\n3. FRONT\n4. DISPLAY\n5. EXIT\n");
        printf("Enter choice: ");
        if (scanf("%d", &choice) != 1) break;

        switch (choice) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &x);
                enqueue(x);
                break;
            case 2: dequeue(); break;
            case 3: frontElement(); break;
            case 4: display(); break;
            case 5: return 0;
            default: printf("Invalid choice\n");
        }
    }
    return 0;
}
