# DSA Assignment: Stack & Circular Queue

**Name:** Ali Abbas Zaidi
**Student ID:** BC2025569
**Course:** BCA, 3rd Semester

Both programs are written in C using plain arrays (no built-in stack/queue library).

---

## Files

| File | Description |
|------|-------------|
| `stack.c` | Q1: Stack using array |
| `circular_queue.c` | Q2: Circular Queue using array |

## How to Run

```
gcc stack.c -o stack
./stack

gcc circular_queue.c -o circular_queue
./circular_queue
```

---

# Q1. Stack using Array

**Operations:** PUSH, POP, PEEK, DISPLAY

- **Stack Overflow:** `top == MAX - 1`, push is rejected.
- **Stack Underflow:** `top == -1`, pop is rejected.

### Complexity

| Operation | Time | Space |
|-----------|------|-------|
| PUSH | O(1) | O(1) |
| POP | O(1) | O(1) |
| PEEK | O(1) | O(1) |
| DISPLAY | O(n) | O(1) |

The stack itself uses O(n) space for an array of size n.

### What if the stack is full?

The stack size is fixed, so when it is full and the user tries to push another element, there is no free index left. Writing anyway would go outside the array (undefined behaviour). So the program checks `top == MAX - 1` first and prints **"Stack Overflow"** instead of inserting.

---

# Q2. Circular Queue using Array

**Operations:** ENQUEUE, DEQUEUE, FRONT, DISPLAY

Indexes wrap around using `(index + 1) % MAX`.

**Full vs Empty:** a `count` variable stores the number of elements.

- Empty: `count == 0`
- Full: `count == MAX`

Without `count`, `front == rear` would be true in both cases and we could not tell them apart.

### Complexity

| Operation | Time | Space |
|-----------|------|-------|
| ENQUEUE | O(1) | O(1) |
| DEQUEUE | O(1) | O(1) |
| FRONT | O(1) | O(1) |
| DISPLAY | O(n) | O(1) |

The queue itself uses O(n) space for an array of size n.

### Circular Queue vs Linear Queue

| Point | Linear Queue | Circular Queue |
|-------|--------------|----------------|
| Rear movement | Only moves forward | Wraps to index 0 |
| Freed space | Wasted after dequeue | Reused |
| Memory use | Poor | Better |

**Why circular is better:** after dequeues, the positions at the start of the array become free. A circular queue reuses them by wrapping `rear` back to the beginning, so the whole array is utilised.

**Problem in a linear queue:** when `rear` reaches the last index, the queue is reported as full even if many positions at the beginning are empty (because `front` has moved forward). Those empty slots can never be used again unless all elements are shifted, which costs O(n).

---

## Sample Output (Stack)

```
Pushed 10
Pushed 20
Stack (top to bottom): 20 10
Popped 20
Popped 10
Stack Underflow! Nothing to pop
```
